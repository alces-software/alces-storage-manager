## Table of Contents

- [Getting Started](GettingStarted.md)
- [Location](Location.md)
- [Confirming Navigation](ConfirmingNavigation.md)
- [Query Support](QuerySupport.md)
- [Basename Support](BasenameSupport.md)
- [Caveats of Using Hash History](HashHistoryCaveats.md)
- [Glossary](Glossary.md)
