# react-addons-test-utils

This package provides the React TestUtils add-on.

See <https://facebook.github.io/react/docs/test-utils.html> for more information.