'use strict';

module.exports = require('tough-cookie');
