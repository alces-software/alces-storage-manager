declare function pascalCase (value: string, locale?: string): string;

export = pascalCase;
