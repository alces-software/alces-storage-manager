'use strict';

module.exports = {
  end: require('./end'),
  properties: require('./properties')
};