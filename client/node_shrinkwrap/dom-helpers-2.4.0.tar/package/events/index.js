'use strict';
var on = require('./on'),
    off = require('./off'),
    filter = require('./filter');

module.exports = { on: on, off: off, filter: filter };