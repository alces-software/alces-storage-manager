# react-addons-update

This package provides the React updates add-on.

See <https://facebook.github.io/react/docs/update.html> for more information.