
# matches-selector

  Check if an element matches a given selector.  For use with browserify

## Installation

    $ npm install matches-selector

## Example

```js
var matches = require('matches-selector');
matches(el, 'ul li a');
// => true
```

## License

  MIT
