declare function dotCase (value: string, locale?: string): string;

export = dotCase;
