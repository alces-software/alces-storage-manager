## 0.6.0
* Support for React 0.14.
* Use lodash for sorting.

## 0.5.0
* Pass down `buildRowOptions` to Table.

## 0.4.0

* Reinitialize state when props change. (Fixes #5).

## 0.3.0

* Support for React 0.13.0.

## 0.2.0

* Add aria- attributes for accessibility.

### Breaking changes

* The values for order now are 'ascending' and 'descending' instead of 'asc' and 'desc'.

## 0.1.1

* Use css instead of less.
* Use MIT license.

## 0.1.0

* Initial release.
