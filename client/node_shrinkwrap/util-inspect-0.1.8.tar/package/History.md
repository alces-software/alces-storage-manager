
0.1.8 / 2014-02-14
==================

 * index: fix `document.all` type stuff

0.1.7 / 2014-02-14
==================

 * index: avoid double call to `Object.keys`

0.1.6 / 2014-02-14
==================

 * index: fix usage of `Array#reduce` for old browsers

0.1.5 / 2014-02-14
==================

 * index: fix usage of `indexOf` for older browsers

0.1.4 / 2014-02-14
==================

 * index: make `getOwnPropertyNames` and `getOwnPropertyDescriptor`
   optional for old browsers

0.1.3 / 2014-02-14
==================

 * index: add support for Array#map on older browsers

0.1.2 / 2014-02-14
==================

 * index: added support for Array#forEach on older browsers

0.1.1 / 2014-02-14
==================

 * index: added missing colors and styles

0.1.0 / 2014-02-14
==================

 * index: fix `_extend` usage

0.0.1 / 2014-02-14
==================

 * initial release
