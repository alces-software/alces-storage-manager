module.exports = require('./callback');
