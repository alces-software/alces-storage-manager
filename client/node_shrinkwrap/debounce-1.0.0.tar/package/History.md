
1.0.0 / 2014-06-21
==================

 * Readme: attribute underscore.js in the License section
 * index: rewrite to use underscore.js' implementation (#2, @TooTallNate)
 * component, package: add "date-now" as a dependency
 * test: fix test
 * component, package: add "keywords" array
 * package: adjust "description"
 * package: added "repository" field (#1, @juliangruber)

0.0.3 / 2013-08-21
==================

 * immediate now defaults to `false`

0.0.2 / 2013-07-27
==================

 * consolidated with TJ's debounce

0.0.1 / 2012-11-5
==================

 * Initial release
