import React from 'react';
export default function(props) {
  let {children} = props; // eslint-disable-line react/prop-types
  return <div>{children}</div>;
}
