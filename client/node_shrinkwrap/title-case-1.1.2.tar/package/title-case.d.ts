declare function titleCase (value: string, locale?: string): string;

export = titleCase;
