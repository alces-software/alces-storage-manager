# ensure-posix-path

[![Build Status](https://travis-ci.org/stefanpenner/ensure-posix-path.svg)](https://travis-ci.org/stefanpenner/ensure-posix-path)
[![Build status](https://ci.appveyor.com/api/projects/status/bt015k54b2ohk1oi?svg=true)](https://ci.appveyor.com/project/embercli/ensure-posix-path)
