
1.0.3 / 2015-11-09
==================

  * fix for server

1.0.2 / 2015-11-07
==================

  * fix coloring for browsers. would be nice to actually support colors in the browser, but that can come later
  * fix readme

1.0.1 / 2015-10-10
==================

  * add more compatible formatting and fix function

1.0.1 / 2010-01-03
==================

  * Initial release
