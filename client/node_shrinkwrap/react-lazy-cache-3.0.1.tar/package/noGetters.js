module.exports = require('./lib/noGetters');
