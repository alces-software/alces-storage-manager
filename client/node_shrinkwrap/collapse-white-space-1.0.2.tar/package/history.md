<!--remark setext-->

<!--lint disable no-multiple-toplevel-headings-->

1.0.2 / 2016-07-23
==================

*   Fix `readme.md` ([`03823ce`](https://github.com/wooorm/collapse-white-space/commit/03823ce))

1.0.1 / 2016-07-23
==================

*   Rewrite module ([`6d48e8d`](https://github.com/wooorm/collapse-white-space/commit/6d48e8d))

1.0.0 / 2015-07-12
==================
