# Changelog

## v0.3.0

- Refactor to use new application structure
- Use eslint
- src folder for ES6/7 code ran through babel to lib
- More helpful scripts
- Simpler test
- Less dependencies
- Remove webpack
- Add api docs
- Updated readme

## v0.2.5

- Allow React to be 0.12 or greater, actually fixing #2.

## v0.2.4

- Relax React dependency which closes #2.

## v0.2.3

- Revert back to using `lg` instead of `1x` for size.

## v0.2.2

- Update README
  - Add API reference.
  - General cleaup.

## v0.2.1

- Properly assign props to component.

## v0.2.0

- Reverting back to non-ES6 code to make more consumable.

## v0.1.0

- Move over to ES6 imports/emports
- Use JSX instead of `React.createElement`
