/*
 * A noop version in case your tests are browserified (eg, when using
 * testling).
 */

module.exports = function () {}
