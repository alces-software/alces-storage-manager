/* this module will have side effects if it's ran more than once.
 * we're gonna test for that. */

global._rerequirable_count++
