/* global describe, it */

describe('standard', function () {
  it('is conformed to', require('mocha-standard'))
})
