These examples are here so you can see what failures look like.

Run `mocha one.js` or `mocha two.js` to see.
