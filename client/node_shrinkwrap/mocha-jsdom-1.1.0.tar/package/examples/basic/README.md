This is a basic example of what you can put in your project's `test/` folder.
It will allow you to run tests in both jsdom (iojs/node) and the browser.
